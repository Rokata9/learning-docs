package com.example.liquidglasslab.chapter07

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.liquidglasslab.ui.theme.LiquidGlassLabTheme
import java.util.Locale
import kotlin.math.max

/*
 * LESSON SCOPE
 *
 * Lessons 7.1–7.6 already produce a blurred, tinted, saturation-quieted
 * glass group with a sharp label on top. This file adds one later stroke:
 *
 * glass group
 * -> inset the panel path by (rim width / 2)
 * -> drawRoundRect with Stroke of that width
 * -> label stays unstroked
 *
 * Compose Stroke is centered on the path. Half the paint sits outside.
 * Modifier.clip discards that outer half. Insetting by half the width
 * keeps the full band inside the clip.
 *
 * The stroke uses one color on every side. It is not a lighting model.
 */

private const val LessonBlurRadiusDp = 18
private const val ArtworkHeightDp = 176
private const val FixedTintAmount = 0.25f
private const val FixedSaturation = 0.40f

/*
 * 3 dp is thin enough to read as a rim and thick enough to see on a
 * Pixel-class density. The HTML lesson uses 8 CSS px so the lost outer
 * half is obvious. Those two numbers are not the same unit.
 */
private const val DefaultRimWidthDp = 3
private const val MaxRimWidthDp = 8
private const val ArtworkCornerDp = 14

private const val DiagonalStartX = 0.08f
private const val DiagonalStartY = 0.18f
private const val DiagonalEndX = 0.92f
private const val DiagonalEndY = 0.78f
private const val DotCenterX = 0.76f
private const val DotCenterY = 0.28f
private const val BarsStartX = 0.10f
private const val BarsTopY = 0.68f
private const val BarWidthDp = 2
private const val BarHeightDp = 26
private const val BarGapDp = 7
private const val LineWidthDp = 2
private const val DotRadiusDp = 7

private val ExplorerShape = RoundedCornerShape(22.dp)
private val CardShape = RoundedCornerShape(16.dp)
private val ArtworkShape = RoundedCornerShape(ArtworkCornerDp.dp)
private val NavyInterior = Color(red = 0.10f, green = 0.25f, blue = 0.40f)
private val OrangeInterior = Color(red = 0.90f, green = 0.60f, blue = 0.20f)
private val SignalGreen = Color(0xFF10B981)
private val WhiteTint = Color.White
private val RimColor = Color.White.copy(alpha = 0.85f)

private val RimWidthPresetsDp = listOf(0f, 3f, 6f)

private enum class RimPlacement {
    None,
    CenteredOnClip,
    InsetPath,
}

@Composable
internal fun StaticRimExplorer(
    modifier: Modifier = Modifier,
) {
    var rimWidthDp by rememberSaveable {
        mutableFloatStateOf(DefaultRimWidthDp.toFloat())
    }

    val density = LocalDensity.current
    val radiusPx = with(density) { LessonBlurRadiusDp.dp.toPx() }
    val rimWidthPx = with(density) { rimWidthDp.dp.toPx() }
    val cornerPx = with(density) { ArtworkCornerDp.dp.toPx() }
    val insetPx = rimWidthPx / 2f
    val innerRadiusPx = max(0f, cornerPx - insetPx)

    val tintSource = WhiteTint.copy(alpha = FixedTintAmount)
    val saturationMatrix = remember {
        ColorMatrix().apply { setToSaturation(FixedSaturation) }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = ExplorerShape,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = "NEW MECHANISM · INSET CENTERED STROKE",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black,
            )
            Text(
                text = "Keep the quieted glass fixed; mark the edge without lighting",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
            )
            Text(
                text = "Blur stays at 18 dp, tint amount at 0.25, and saturation at 0.40. " +
                    "A later Stroke follows the panel path. Compose centers that stroke, " +
                    "so clipping to the same path discards the outer half. Production " +
                    "insets the path by half the width. The same color runs all the way around.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            RimWidthControls(
                rimWidthDp = rimWidthDp,
                onWidthChange = { rimWidthDp = it },
            )
            RimReadout(
                rimWidthDp = rimWidthDp,
                rimWidthPx = rimWidthPx,
                insetPx = insetPx,
                cornerPx = cornerPx,
                innerRadiusPx = innerRadiusPx,
                blurRadiusPx = radiusPx,
            )
            RimComparisonCard(
                title = "No rim",
                caption = "The frosted fill has no separate edge cue.",
                radiusPx = radiusPx,
                tintSource = tintSource,
                saturationMatrix = saturationMatrix,
                rimWidthPx = rimWidthPx,
                cornerPx = cornerPx,
                placement = RimPlacement.None,
            )
            RimComparisonCard(
                title = "Stroke the clip path",
                caption = "The clip removes the outer half, so the visible band is about half the requested width.",
                radiusPx = radiusPx,
                tintSource = tintSource,
                saturationMatrix = saturationMatrix,
                rimWidthPx = rimWidthPx,
                cornerPx = cornerPx,
                placement = RimPlacement.CenteredOnClip,
            )
            RimComparisonCard(
                title = "Stroke the inset path · production",
                caption = "The path moves inward by width / 2. The full band stays inside the clip.",
                radiusPx = radiusPx,
                tintSource = tintSource,
                saturationMatrix = saturationMatrix,
                rimWidthPx = rimWidthPx,
                cornerPx = cornerPx,
                placement = RimPlacement.InsetPath,
            )
        }
    }
}

@Composable
private fun RimWidthControls(
    rimWidthDp: Float,
    onWidthChange: (Float) -> Unit,
) {
    Surface(
        shape = CardShape,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = "Rim width",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
            )
            Text(
                text = "${formatAmount(rimWidthDp)} dp",
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
            )
            Slider(
                value = rimWidthDp,
                onValueChange = onWidthChange,
                valueRange = 0f..MaxRimWidthDp.toFloat(),
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                RimWidthPresetsDp.forEach { preset ->
                    if (rimWidthDp == preset) {
                        Button(
                            modifier = Modifier.weight(1f),
                            onClick = { onWidthChange(preset) },
                        ) {
                            Text(text = "${preset.toInt()} dp")
                        }
                    } else {
                        OutlinedButton(
                            modifier = Modifier.weight(1f),
                            onClick = { onWidthChange(preset) },
                        ) {
                            Text(text = "${preset.toInt()} dp")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RimReadout(
    rimWidthDp: Float,
    rimWidthPx: Float,
    insetPx: Float,
    cornerPx: Float,
    innerRadiusPx: Float,
    blurRadiusPx: Float,
) {
    Surface(
        shape = CardShape,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = "Inset from the current width",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
            )
            Text(
                text = "blur = ${blurRadiusPx.toInt()} px · tint = 0.25 · saturation = 0.40",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
            )
            Text(
                text = "rim width = ${formatAmount(rimWidthDp)} dp = ${formatPx(rimWidthPx)} px",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
            )
            Text(
                text = "inset = ${formatPx(rimWidthPx)} / 2 = ${formatPx(insetPx)} px",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
            )
            Text(
                text = "inner corner = ${formatPx(cornerPx)} − ${formatPx(insetPx)} = ${formatPx(innerRadiusPx)} px",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
            )
            Text(
                text = if (rimWidthDp == 0f) {
                    "Width 0 draws no stroke."
                } else {
                    "Visible on the clip path ≈ ${formatPx(insetPx)} px. " +
                        "Visible on the inset path = ${formatPx(rimWidthPx)} px."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun RimComparisonCard(
    title: String,
    caption: String,
    radiusPx: Float,
    tintSource: Color,
    saturationMatrix: ColorMatrix,
    rimWidthPx: Float,
    cornerPx: Float,
    placement: RimPlacement,
) {
    Surface(
        shape = CardShape,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(ArtworkHeightDp.dp)
                    .clip(ArtworkShape),
            ) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .graphicsLayer {
                            colorFilter = ColorFilter.colorMatrix(saturationMatrix)
                        },
                ) {
                    Canvas(
                        modifier = Modifier
                            .matchParentSize()
                            .graphicsLayer {
                                renderEffect = BlurEffect(
                                    renderEffect = null,
                                    radiusX = radiusPx,
                                    radiusY = radiusPx,
                                    edgeTreatment = TileMode.Clamp,
                                )
                            },
                    ) {
                        drawLessonArtwork()
                    }
                    Canvas(modifier = Modifier.matchParentSize()) {
                        drawRect(color = tintSource)
                    }
                }
                Canvas(modifier = Modifier.matchParentSize()) {
                    drawStaticRim(
                        placement = placement,
                        rimWidthPx = rimWidthPx,
                        cornerPx = cornerPx,
                    )
                }
                Text(
                    text = "Sharp label",
                    modifier = Modifier.align(Alignment.Center),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            Text(
                text = caption,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun DrawScope.drawStaticRim(
    placement: RimPlacement,
    rimWidthPx: Float,
    cornerPx: Float,
) {
    if (placement == RimPlacement.None || rimWidthPx <= 0f) {
        return
    }
    if (placement == RimPlacement.CenteredOnClip) {
        drawRoundRect(
            color = RimColor,
            topLeft = Offset.Zero,
            size = size,
            cornerRadius = CornerRadius(cornerPx),
            style = Stroke(width = rimWidthPx),
        )
        return
    }
    val inset = rimWidthPx / 2f
    val innerRadius = max(0f, cornerPx - inset)
    drawRoundRect(
        color = RimColor,
        topLeft = Offset(inset, inset),
        size = Size(
            width = size.width - rimWidthPx,
            height = size.height - rimWidthPx,
        ),
        cornerRadius = CornerRadius(innerRadius),
        style = Stroke(width = rimWidthPx),
    )
}

private fun DrawScope.drawLessonArtwork() {
    val halfWidth = size.width / 2f
    drawRect(color = NavyInterior, size = Size(halfWidth, size.height))
    drawRect(
        color = OrangeInterior,
        topLeft = Offset(halfWidth, 0f),
        size = Size(halfWidth, size.height),
    )
    drawLine(
        color = Color.White,
        start = Offset(size.width * DiagonalStartX, size.height * DiagonalStartY),
        end = Offset(size.width * DiagonalEndX, size.height * DiagonalEndY),
        strokeWidth = LineWidthDp.dp.toPx(),
    )
    drawCircle(
        color = SignalGreen,
        radius = DotRadiusDp.dp.toPx(),
        center = Offset(size.width * DotCenterX, size.height * DotCenterY),
    )
    val barWidth = BarWidthDp.dp.toPx()
    val barHeight = BarHeightDp.dp.toPx()
    val barGap = BarGapDp.dp.toPx()
    val barsTop = size.height * BarsTopY
    repeat(5) { index ->
        drawRect(
            color = Color.White,
            topLeft = Offset(
                x = size.width * BarsStartX + index * (barWidth + barGap),
                y = barsTop,
            ),
            size = Size(barWidth, barHeight),
        )
    }
}

private fun formatAmount(value: Float): String {
    return String.format(Locale.US, "%.2f", value)
}

private fun formatPx(value: Float): String {
    return String.format(Locale.US, "%.1f", value)
}

@Preview(
    name = "Lesson 7.7 explorer — dark",
    showBackground = true,
    widthDp = 412,
    heightDp = 915,
    uiMode = Configuration.UI_MODE_NIGHT_YES,
)
@Preview(
    name = "Lesson 7.7 explorer — light",
    showBackground = true,
    widthDp = 412,
    heightDp = 915,
    uiMode = Configuration.UI_MODE_NIGHT_NO,
)
@Composable
private fun StaticRimExplorerPreview() {
    LiquidGlassLabTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .safeDrawingPadding()
                    .padding(8.dp),
            ) {
                StaticRimExplorer()
            }
        }
    }
}
